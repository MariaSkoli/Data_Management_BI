INSERT INTO Region
(ID, [Name], [Population], [Average_Income])
VALUES
(1, 'Agios Dimitrios', 71294, 37987),
(2, 'Nea Smurnh', 63076, 35003),
(3, 'Agia Paraskeui', 57193, 24205),
(4, 'Xalandri', 74192, 25013),
(5, 'Glifada', 82305, 24508),
(6, 'Ilion', 71793, 27803),
(7, 'Voula', 44179, 42317),
(8, 'Lagonisi', 24129 , 22330),
(9, 'Kalivia', 15793, 43157),
(10, 'Ilioupoli', 34187, 25933),
(11, 'Gkizi', 54798, 39917),
(12, 'Dionisos', 14781, 14787),
(13, 'Perissos', 42163, 26516),
(14, 'Ampelokipoi', 52489, 32512),
(15, 'Ekali', 32448, 45129),
(16, 'Elliniko', 42161, 55116),
(17, 'Argiroupoli', 51587, 23384),
(18, 'Kifisia', 32369, 57987),
(19, 'Koukaki', 25168, 45123),
(20, 'Athina', 53492, 37331)
GO


